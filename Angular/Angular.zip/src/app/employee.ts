export class Employee {
    id: number;
    name: string;
    address: string;
    nin: string;
    bankNumber: string;
    salary: number;
}
